// router.js
import {RouterMount,createRouter,runtimeQuit} from 'uni-simple-router';

let [loginStatus,appOnLaunch]=[null,0];
const path='http://192.168.1.101:8021/isLogin'

const  isLogin= async function(){
	return uni.request({
		url:path
	})
}

const loginToPage=async function(to, from,next){
	if(loginStatus==null){
		const [,{data:{status}}]= await isLogin();
		loginStatus=status;
	}
	if(loginStatus===200){		// 已经登录
		if(appOnLaunch===1){
			next({
				name:'tabbar-1',
				NAVTYPE:'pushTab'
			});
		}else{
			next();
		}
	}else{		//未登录 直接放行到登录页面
		if(to.name!='login'){
			next({
				name:'login',
				NAVTYPE:'replace'
			});
		}else{
			next();
		}
	}
}

const router = createRouter({
	platform: process.env.VUE_APP_PLATFORM,  
	routerErrorEach:({type,msg})=>{
		console.log({type,msg})
		// #ifdef APP-PLUS
			if(type===3){
				router.$lockStatus=false;
				runtimeQuit();
			}
		// #endif
	},
	routes: [...ROUTES]
});

//全局路由前置守卫
router.beforeEach((to, from, next) => {
	appOnLaunch++;
	if(to.meta.auth){
		loginToPage(to, from,next);
	}else{
		// #ifdef H5
			next();
		// #endif
		
		// #ifndef H5
			if(appOnLaunch===1){
				loginToPage(to, from,next);
			}else{
				next();
			}
		// #endif
	}
});
// 全局路由后置守卫
router.afterEach((to, from) => {
    console.log('跳转结束')
})

export {
	router,
	RouterMount
}