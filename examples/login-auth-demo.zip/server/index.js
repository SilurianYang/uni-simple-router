const express = require('express');
const app = new express();

const status=200;  //200 表示登录  其他未登录

app.use((req, res,next) => {
	res.header('Access-Control-Allow-Origin', '*');
	next();
})

app.get('/isLogin', (req, res) => {
	res.json({
		status, 
	});
})

const server = app.listen(8021, () => {
	const port = server.address().port;
	console.log(`http://127.0.0.1:${port}`);
});
