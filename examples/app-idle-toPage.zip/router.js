import {webviewStartHold,webviewStopHold} from './util.js'
import {RouterMount,createRouter,runtimeQuit} from 'uni-simple-router';


const router = createRouter({
	platform: process.env.VUE_APP_PLATFORM,  
	routerBeforeEach:(to,from,next)=>{
		webviewStopHold();
		next();
	},
	routerAfterEach(to,from){
		webviewStartHold(to);
	},
    routerErrorEach:({type,msg})=>{
        console.log({type,msg})
        // #ifdef APP-PLUS
            if(type===3){
                router.$lockStatus=false;
                runtimeQuit();
            }
        // #endif
    },
	routes: [...ROUTES]
});
//全局路由前置守卫
router.beforeEach((to, from, next) => {
	next();
});

export {
	router,
	RouterMount
}