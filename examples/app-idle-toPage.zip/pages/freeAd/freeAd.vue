<template>
	<view>
		<h1>这是闲时的广告页面</h1>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
