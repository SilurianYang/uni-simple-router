import {router} from './router.js'


const endTimeMS=10000;			//无操作多少毫秒后去广告页面
const endTimeToPath='/pages/freeAd/freeAd'		//无操作时间到后需要去的页面
let  endTimeStop=null;


export function endTimeDoWhat(){
	clearTimeout(endTimeStop);
	endTimeStop=setTimeout(()=>{
		router.push({path:endTimeToPath})
	},endTimeMS)
}
export function doBindEndTime(){
	clearTimeout(endTimeStop);
	endTimeDoWhat();
}

export function webviewStartHold({path}){
	if(path===endTimeToPath){
		return false;
	}
	const pages=getCurrentPages();
	const page=pages[pages.length-1];
	const webview=page.$getAppWebview();
	if(webview){
		endTimeDoWhat();
		webview.addEventListener('touchstart',doBindEndTime,false)
	}else{
		console.log(`${path} 页面监听触摸事件失败！`)
	}
}


export function webviewStopHold(){
	const pages=getCurrentPages();
	for(let i=0;i<pages.length;i++){
		pages[i].$getAppWebview().removeEventListener('touchstart',doBindEndTime);
	}
}