/**
 * 截止 1.3.5 版本 不做任何操作
 * @param {element} el dom节点
 */
const appMount = function (Vim) {
    Vim.$mount();
};
export default appMount;
