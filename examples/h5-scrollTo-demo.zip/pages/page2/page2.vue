<template>
	<view>
		<div class="item" v-for="(item,index) in 10" :key="index">{{item}}</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.item{
		height: 200rpx;
		background-color: #F0AD4E;
		margin-bottom: 30rpx;
	}
</style>
